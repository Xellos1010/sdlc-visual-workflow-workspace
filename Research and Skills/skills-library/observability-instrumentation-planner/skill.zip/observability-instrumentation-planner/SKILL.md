---
name: observability-instrumentation-planner
description: define logs, metrics, traces, spans, audit events, structured errors, correlation fields, debug affordances, alert candidates, and measurement points for cloud-agent sdlc design work. use after complexity-notation-assessor or when io contracts, runtime context, adapters, events, retries, performance budgets, or validation requirements show the implementation needs inspectable behavior before pseudocode review verification, implementation planning, generated-code review, validation, adr drafting, parity sync, or continuity updates.
---

# Observability Instrumentation Planner

Plan the minimum useful instrumentation needed to inspect correctness, performance, reliability, and operational behavior after implementation.

## Core rule

Instrumentation must answer specific operational or debugging questions. Do not add noisy logs or metrics without a decision, failure mode, performance budget, or validation need.

## Required inputs

- `complexity_assessment.json`
- `io_contract.schema.json`, `event_contract.json`, adapter contract, runtime context, and acceptance criteria when available
- Error taxonomy, retry policy, idempotency rules, audit/compliance requirements, and validation commands when available

## Workflow

1. Identify what must be observable: entrypoints, side effects, external calls, retries, errors, performance hotspots, event handlers, state transitions, and user-visible outcomes.
2. Define structured log points with stable event names and fields. Exclude secrets and sensitive payloads.
3. Define metrics with names, units, dimensions, cardinality limits, and budgets or thresholds.
4. Define trace spans around meaningful boundaries and include correlation IDs.
5. Define audit events only when needed for compliance, durable decision records, or user-visible mutations.
6. Define alert candidates and dashboard evidence only when the signal is actionable.
7. Produce `observability_plan.json` using `references/observability-plan.schema.json`.
8. Handoff to `pseudocode-review-verifier`.

## Output contract

Always return this structure:

```markdown
# Observability Plan

## Questions instrumentation must answer
- <question, owner, signal>

## Logs
| Point | Event name | Level | Fields | Redaction rule |
|---|---|---|---|---|

## Metrics
| Metric | Type | Unit | Dimensions | Budget/threshold |
|---|---|---|---|---|

## Traces
| Span | Boundary | Attributes | Parent/child relation |
|---|---|---|---|

## Audit and alerts
- Audit events:
- Alert candidates:
- Dashboard or evidence needs:

## observability_plan.json
```json
{}
```

## next_skill_handoff
Send `observability_plan.json` to `pseudocode-review-verifier`.
```

## Guardrails

- Do not log secrets, credentials, tokens, raw user data, or regulated payloads.
- Do not create high-cardinality metrics from user IDs, request IDs, raw paths, or unbounded labels.
- Do not require instrumentation that conflicts with existing observability conventions.
