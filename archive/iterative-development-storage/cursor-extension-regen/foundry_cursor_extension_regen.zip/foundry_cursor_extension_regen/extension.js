const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const { spawn } = require('child_process');

const DEFAULT_PLAN = {
  planId: 'bootstrap-plan',
  title: 'Foundry bootstrap plan',
  approval: {
    mode: 'manual',
    status: 'awaiting_approval',
    autoApprove: false,
    approvedAt: null,
    approvedBy: null
  },
  diagrams: [
    {
      id: 'ecosystem-overview',
      title: 'Ecosystem Overview',
      mermaid: [
        'flowchart TB',
        '  req[Requests / Telemetry / Inspection] --> plan[Plan + Blast Radius]',
        '  plan --> gate{Approval}',
        '  gate -->|manual| human[Human Approves]',
        '  gate -->|auto| auto[Auto Approved]',
        '  human --> exec[Task Execution]',
        '  auto --> exec',
        '  exec --> verify[Verification + Evidence]',
        '  verify --> learn[Learning + Memory]',
        '  learn --> req'
      ].join('\\n')
    }
  ],
  tasks: [
    {
      id: 'task-impact-analysis',
      title: 'Impact + blast radius analysis',
      description: 'Enumerate impacted systems, shared patterns, mirrored modules, rules, and verification updates before implementation.',
      agent: 'foundry-blast-radius',
      status: 'ready',
      watchHint: 'Inspect output log after start.',
      prompt: 'Review the change request, enumerate the full blast radius, identify mirrored modules and shared abstractions, and propose follow-on tasks.'
    },
    {
      id: 'task-implementation',
      title: 'Bounded implementation',
      description: 'Implement the approved changes only after the blast radius has been accepted.',
      agent: 'foundry-implementer',
      status: 'blocked',
      blockedBy: ['task-impact-analysis'],
      watchHint: 'Inspect output log after start.',
      prompt: 'Implement the approved work order within the allowed files, update tests, and emit a concise patch summary.'
    },
    {
      id: 'task-verification',
      title: 'Independent verification',
      description: 'Verify acceptance criteria and fail if mirrored functionality or evidence is missing.',
      agent: 'foundry-verifier',
      status: 'blocked',
      blockedBy: ['task-implementation'],
      watchHint: 'Inspect output log after start.',
      prompt: 'Verify the completed work independently, map acceptance criteria to evidence, and block sign-off if coverage is incomplete.'
    }
  ]
};

function extensionState(context) {
  if (!context._foundryState) {
    context._foundryState = {
      panel: null,
      popoutServer: null,
      popoutPort: null,
      popoutState: {
        title: 'Diagram',
        mermaid: 'graph TD\\n  A[No diagram selected] --> B[Open Foundry panel]'
      },
      processes: new Map(),
      outputChannels: new Map()
    };
  }
  return context._foundryState;
}

function getConfig() {
  return vscode.workspace.getConfiguration('flagshipFoundry');
}

function getWorkspaceRoot() {
  const folder = vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders[0];
  return folder ? folder.uri.fsPath : null;
}

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function safeReadJson(filePath, fallback = null) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(filePath, value) {
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2) + os.EOL, 'utf8');
}

function resolvePaths() {
  const workspaceRoot = getWorkspaceRoot();
  if (!workspaceRoot) {
    throw new Error('Open a workspace folder before using Flagship Foundry.');
  }
  const config = getConfig();
  const planRel = config.get('taskFile', '.foundry/tasks/current-plan.json');
  const diagramRel = config.get('diagramDirectory', '.foundry/diagrams');
  const runtimeRel = config.get('runtimeDirectory', '.foundry/runtime');
  const planPath = path.join(workspaceRoot, planRel);
  const diagramDir = path.join(workspaceRoot, diagramRel);
  const runtimeDir = path.join(workspaceRoot, runtimeRel);
  const promptsDir = path.join(runtimeDir, 'prompts');
  const logsDir = path.join(runtimeDir, 'logs');
  const agentsDir = path.join(workspaceRoot, '.claude', 'agents');
  const mcpConfigPath = path.join(workspaceRoot, '.cursor', 'mcp.json');
  return { workspaceRoot, planPath, diagramDir, runtimeDir, promptsDir, logsDir, agentsDir, mcpConfigPath };
}

function createSampleArtifactsIfMissing() {
  const { planPath, diagramDir } = resolvePaths();
  if (!fs.existsSync(planPath)) {
    writeJson(planPath, DEFAULT_PLAN);
  }
  ensureDir(diagramDir);
  const defaultDiagram = path.join(diagramDir, 'ecosystem-overview.mmd');
  if (!fs.existsSync(defaultDiagram)) {
    fs.writeFileSync(defaultDiagram, DEFAULT_PLAN.diagrams[0].mermaid + os.EOL, 'utf8');
  }
}

function loadPlanModel() {
  createSampleArtifactsIfMissing();
  const { planPath, diagramDir } = resolvePaths();
  const model = safeReadJson(planPath, JSON.parse(JSON.stringify(DEFAULT_PLAN)));
  ensureDir(diagramDir);
  const diagramFiles = fs.readdirSync(diagramDir)
    .filter((name) => /\.(mmd|mermaid|md)$/i.test(name))
    .sort();
  const discoveredDiagrams = diagramFiles.map((name) => ({
    id: name.replace(/\.[^.]+$/, ''),
    title: name.replace(/\.[^.]+$/, ''),
    fileName: name,
    mermaid: fs.readFileSync(path.join(diagramDir, name), 'utf8')
  }));
  model.diagrams = discoveredDiagrams.length > 0 ? discoveredDiagrams : (model.diagrams || []);
  model.tasks = Array.isArray(model.tasks) ? model.tasks : [];
  model.approval = model.approval || DEFAULT_PLAN.approval;
  return model;
}

function savePlanModel(model) {
  const { planPath } = resolvePaths();
  writeJson(planPath, model);
}

function readMcpConfig() {
  const { mcpConfigPath } = resolvePaths();
  return safeReadJson(mcpConfigPath, { mcpServers: {} });
}

function saveMcpConfig(configValue) {
  const { mcpConfigPath } = resolvePaths();
  writeJson(mcpConfigPath, configValue);
}

function shellEscape(value) {
  const text = String(value == null ? '' : value);
  if (process.platform === 'win32') {
    return '"' + text.replace(/"/g, '""') + '"';
  }
  return '\'' + text.replace(/'/g, "'\\''") + '\'';
}

function replaceTemplate(template, replacements) {
  let output = template;
  for (const [key, value] of Object.entries(replacements)) {
    output = output.replace(new RegExp(`\\{${key}\\}`, 'g'), String(value));
  }
  return output;
}

function taskOutputChannel(context, taskId, title) {
  const state = extensionState(context);
  if (!state.outputChannels.has(taskId)) {
    state.outputChannels.set(taskId, vscode.window.createOutputChannel(`Foundry ${title || taskId}`));
  }
  return state.outputChannels.get(taskId);
}

function getTaskById(model, taskId) {
  return model.tasks.find((task) => task.id === taskId);
}

function unblockEligibleTasks(model) {
  const completedIds = new Set(model.tasks.filter((task) => task.status === 'completed').map((task) => task.id));
  for (const task of model.tasks) {
    if ((task.status === 'blocked' || task.status === 'ready') && Array.isArray(task.blockedBy) && task.blockedBy.length > 0) {
      const blocked = task.blockedBy.some((id) => !completedIds.has(id));
      if (!blocked && task.status === 'blocked') {
        task.status = 'ready';
      }
    }
  }
}

function selectedDiagram(model) {
  if (!model.diagrams || model.diagrams.length === 0) {
    return { id: 'empty', title: 'No diagram', mermaid: 'graph TD\\n  A[No diagram found] --> B[Add .mmd files under .foundry/diagrams]' };
  }
  return model.diagrams[0];
}

function promptForTask(model, task) {
  const lines = [
    `# Work Order: ${task.title}`,
    '',
    `Task ID: ${task.id}`,
    `Agent: ${task.agent || 'foundry-general'}`,
    `Status: ${task.status}`,
    '',
    '## Task Description',
    task.description || '',
    '',
    '## Expected Operation',
    task.prompt || '',
    '',
    '## Current Plan Context',
    `Plan: ${model.title}`,
    `Approval mode: ${model.approval && model.approval.mode ? model.approval.mode : 'manual'}`,
    '',
    '## Non-negotiables',
    '- Respect the approved plan and blast-radius scope.',
    '- Do not claim completion without evidence.',
    '- Surface mirrored modules, similar patterns, and verification gaps.',
    '- Emit a concise summary that another agent can resume from.'
  ];
  return lines.join(os.EOL);
}

function runConfiguredTaskCommand(context, model, task) {
  const state = extensionState(context);
  const config = getConfig();
  const template = config.get('agentCommandTemplate', '').trim();
  const { workspaceRoot, promptsDir, logsDir } = resolvePaths();
  ensureDir(promptsDir);
  ensureDir(logsDir);

  const promptFile = path.join(promptsDir, `${task.id}.md`);
  fs.writeFileSync(promptFile, promptForTask(model, task) + os.EOL, 'utf8');

  const output = taskOutputChannel(context, task.id, task.title);
  output.clear();
  output.appendLine(`[${new Date().toISOString()}] Preparing task ${task.id}`);
  output.appendLine(`Prompt file: ${promptFile}`);

  if (!template) {
    output.appendLine('No agent command template is configured. Set flagshipFoundry.agentCommandTemplate to launch Claude or another runtime automatically.');
    output.show(true);
    return { started: false, promptFile, command: null };
  }

  const command = replaceTemplate(template, {
    workspaceRoot: shellEscape(workspaceRoot),
    agent: shellEscape(task.agent || 'foundry-general'),
    taskId: shellEscape(task.id),
    title: shellEscape(task.title),
    promptFile: shellEscape(promptFile)
  });

  output.appendLine(`Command: ${command}`);
  output.show(true);

  const child = spawn(command, {
    cwd: workspaceRoot,
    shell: true,
    env: { ...process.env }
  });

  const logPath = path.join(logsDir, `${task.id}.log`);
  const logStream = fs.createWriteStream(logPath, { flags: 'a' });
  const handleData = (chunk, prefix) => {
    const text = chunk.toString();
    output.append(text);
    logStream.write(text);
    if (prefix) {
      // reserved for future structured parsing
    }
  };

  child.stdout.on('data', (chunk) => handleData(chunk, 'stdout'));
  child.stderr.on('data', (chunk) => handleData(chunk, 'stderr'));
  child.on('exit', (code, signal) => {
    logStream.end();
    const latest = loadPlanModel();
    const latestTask = getTaskById(latest, task.id);
    if (latestTask) {
      if (latestTask.status !== 'paused' && latestTask.status !== 'stopped') {
        latestTask.status = code === 0 ? 'completed' : 'failed';
        latestTask.lastExit = { code, signal, finishedAt: new Date().toISOString(), logPath };
        unblockEligibleTasks(latest);
        savePlanModel(latest);
      }
    }
    state.processes.delete(task.id);
    refreshPanel(context).catch(() => undefined);
  });

  state.processes.set(task.id, { child, output, promptFile, logPath, command });
  return { started: true, promptFile, logPath, command };
}

async function startTask(context, taskId) {
  const model = loadPlanModel();
  const task = getTaskById(model, taskId);
  if (!task) {
    throw new Error(`Unknown task: ${taskId}`);
  }
  if (model.approval && model.approval.mode === 'manual' && model.approval.status !== 'approved') {
    throw new Error('Plan is in manual mode and has not been approved yet. Approve the plan before starting tasks.');
  }
  if (task.status === 'blocked') {
    throw new Error(`Task ${task.title} is blocked by prerequisites.`);
  }
  task.status = 'running';
  task.startedAt = new Date().toISOString();
  const runtime = runConfiguredTaskCommand(context, model, task);
  task.runtime = {
    promptFile: runtime.promptFile,
    logPath: runtime.logPath || null,
    command: runtime.command || null,
    launchedAt: new Date().toISOString(),
    externallyManaged: !runtime.started
  };
  savePlanModel(model);
  await refreshPanel(context);
  return runtime;
}

async function watchTask(context, taskId) {
  const state = extensionState(context);
  const processEntry = state.processes.get(taskId);
  if (processEntry) {
    processEntry.output.show(true);
    return;
  }
  const model = loadPlanModel();
  const task = getTaskById(model, taskId);
  if (!task) {
    throw new Error(`Unknown task: ${taskId}`);
  }
  const output = taskOutputChannel(context, task.id, task.title);
  output.show(true);
  if (task.runtime && task.runtime.logPath && fs.existsSync(task.runtime.logPath)) {
    output.clear();
    output.append(fs.readFileSync(task.runtime.logPath, 'utf8'));
  } else if (task.runtime && task.runtime.promptFile && fs.existsSync(task.runtime.promptFile)) {
    output.appendLine(`Prompt file: ${task.runtime.promptFile}`);
    output.append(fs.readFileSync(task.runtime.promptFile, 'utf8'));
  } else {
    output.appendLine('No live process or saved log found for this task.');
  }
}

async function pauseTask(context, taskId) {
  const state = extensionState(context);
  const model = loadPlanModel();
  const task = getTaskById(model, taskId);
  if (!task) {
    throw new Error(`Unknown task: ${taskId}`);
  }
  const processEntry = state.processes.get(taskId);
  if (!processEntry) {
    task.status = 'paused';
    savePlanModel(model);
    await refreshPanel(context);
    return;
  }
  if (process.platform !== 'win32') {
    processEntry.child.kill('SIGSTOP');
  } else {
    processEntry.child.kill('SIGINT');
  }
  task.status = 'paused';
  task.pausedAt = new Date().toISOString();
  savePlanModel(model);
  await refreshPanel(context);
}

async function resumeTask(context, taskId) {
  const state = extensionState(context);
  const model = loadPlanModel();
  const task = getTaskById(model, taskId);
  if (!task) {
    throw new Error(`Unknown task: ${taskId}`);
  }
  const processEntry = state.processes.get(taskId);
  if (processEntry && process.platform !== 'win32') {
    processEntry.child.kill('SIGCONT');
    task.status = 'running';
    savePlanModel(model);
    await refreshPanel(context);
    return;
  }
  await startTask(context, taskId);
}

async function stopTask(context, taskId) {
  const state = extensionState(context);
  const model = loadPlanModel();
  const task = getTaskById(model, taskId);
  if (!task) {
    throw new Error(`Unknown task: ${taskId}`);
  }
  const processEntry = state.processes.get(taskId);
  if (processEntry) {
    processEntry.child.kill('SIGTERM');
    state.processes.delete(taskId);
  }
  task.status = 'stopped';
  task.stoppedAt = new Date().toISOString();
  savePlanModel(model);
  await refreshPanel(context);
}

async function approvePlan(context, autoApprove = false) {
  const model = loadPlanModel();
  model.approval = model.approval || {};
  model.approval.mode = autoApprove ? 'auto' : (model.approval.mode || 'manual');
  model.approval.status = 'approved';
  model.approval.autoApprove = autoApprove;
  model.approval.approvedAt = new Date().toISOString();
  model.approval.approvedBy = autoApprove ? 'auto' : 'human';
  unblockEligibleTasks(model);
  savePlanModel(model);
  await refreshPanel(context);
}

async function toggleAutoApprove(context, enabled) {
  const model = loadPlanModel();
  model.approval = model.approval || {};
  model.approval.mode = enabled ? 'auto' : 'manual';
  model.approval.autoApprove = enabled;
  if (enabled && model.approval.status !== 'approved') {
    model.approval.status = 'approved';
    model.approval.approvedAt = new Date().toISOString();
    model.approval.approvedBy = 'auto';
  }
  savePlanModel(model);
  await refreshPanel(context);
}

function generateClaudeAgentFiles() {
  const { agentsDir } = resolvePaths();
  ensureDir(agentsDir);
  const agentFiles = {
    'foundry-explorer.md': `---\nname: foundry-explorer\ndescription: Explore the codebase, diagrams, rules, and architecture artifacts for a Foundry task. Use proactively before planning or implementation.\ntools: Read, Grep, Glob, Bash\nmodel: haiku\npermissionMode: plan\nmemory: project\n---\n\nYou are a fast read-only exploration agent for the Foundry SDLC pipeline.\n\nResponsibilities:\n1. Find the relevant code paths, diagrams, rules, and task-state artifacts.\n2. Summarize current structure, duplication, and probable blast radius.\n3. Keep findings concise and evidence-based.\n4. Update project memory with recurring paths, system boundaries, and unresolved questions.\n`,
    'foundry-blast-radius.md': `---\nname: foundry-blast-radius\ndescription: Analyze blast radius, mirrored modules, related systems, shared abstractions, and verification needs for a planned change. Use proactively before implementation.\ntools: Read, Grep, Glob, Bash\nmodel: sonnet\npermissionMode: plan\nmemory: project\n---\n\nYou are the blast-radius specialist for the Foundry pipeline.\n\nYour job is to stop false completion by identifying:\n- sibling modules with similar behavior\n- shared libs and mirrored files\n- diagrams, rules, and docs that must also change\n- verification and regression work needed to prove completeness\n\nReturn:\n1. impacted systems\n2. impacted components\n3. hidden or mirrored surfaces\n4. follow-on task recommendations\n5. evidence gaps\n`,
    'foundry-implementer.md': `---\nname: foundry-implementer\ndescription: Implement an approved Foundry task within explicit file and system boundaries. Use after blast radius analysis and approval are complete.\ntools: Read, Edit, Write, Grep, Glob, Bash\nmodel: sonnet\npermissionMode: acceptEdits\nmemory: project\n---\n\nYou are the bounded implementation agent for the Foundry pipeline.\n\nRules:\n- Respect the approved task boundaries.\n- Do not claim completion without noting evidence and likely blast-radius spillover.\n- Update your project memory with patterns, contracts, and architectural choices encountered.\n- Keep implementation notes resumable by another agent.\n`,
    'foundry-verifier.md': `---\nname: foundry-verifier\ndescription: Independently verify a Foundry task against acceptance criteria, blast radius, and regression risk. Use proactively after implementation.\ntools: Read, Grep, Glob, Bash\nmodel: sonnet\npermissionMode: plan\nmemory: project\n---\n\nYou are the skeptical verification agent for the Foundry pipeline.\n\nYou must:\n1. map every acceptance criterion to evidence\n2. check mirrored behavior and similar features\n3. fail verification when coverage is incomplete\n4. suggest missing docs, diagrams, and regression tests\n5. record recurring failure patterns in memory\n`,
    'foundry-doc-curator.md': `---\nname: foundry-doc-curator\ndescription: Update diagrams, runbooks, handoff notes, and task-state continuity for a Foundry task. Use after implementation and verification.\ntools: Read, Edit, Write, Grep, Glob\nmodel: haiku\npermissionMode: acceptEdits\nmemory: project\n---\n\nYou maintain resumable continuity for the Foundry pipeline.\n\nUpdate:\n- diagrams\n- runbooks\n- handoff notes\n- task-state and continuity artifacts\n- fix-memory records when a resolved bug teaches a reusable lesson\n`
  };
  for (const [name, content] of Object.entries(agentFiles)) {
    fs.writeFileSync(path.join(agentsDir, name), content.replace(/\n/g, os.EOL), 'utf8');
  }
  return Object.keys(agentFiles).map((name) => path.join(agentsDir, name));
}

function ensureCursorMcpConfig() {
  const config = readMcpConfig();
  config.mcpServers = config.mcpServers || {};
  config.mcpServers.flagshipFoundry = {
    command: 'node',
    args: ['apps/foundry-mcp-server/src/server.mjs']
  };
  saveMcpConfig(config);
  return config;
}

function getCurrentDiagram(model, requestedId) {
  if (requestedId) {
    const match = model.diagrams.find((diagram) => diagram.id === requestedId);
    if (match) {
      return match;
    }
  }
  return selectedDiagram(model);
}

async function ensurePopoutServer(context) {
  const state = extensionState(context);
  if (state.popoutServer && state.popoutPort) {
    return state.popoutPort;
  }
  const server = http.createServer((req, res) => {
    if (req.url === '/state.json') {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify(state.popoutState));
      return;
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(`<!doctype html>\n<html>\n<head>\n<meta charset="utf-8"/>\n<title>${state.popoutState.title}</title>\n<style>body{margin:0;padding:16px;font-family:Inter,Arial,sans-serif;background:#111;color:#f5f5f5} #diagram{background:#1a1a1a;border-radius:12px;padding:16px;overflow:auto;min-height:80vh} h1{font-size:18px;margin:0 0 12px 0}</style>\n<script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>\n</head>\n<body>\n<h1 id="title"></h1>\n<div id="diagram"></div>\n<script>\nmermaid.initialize({ startOnLoad:false, securityLevel:'loose', theme:'dark', flowchart:{ useMaxWidth:true } });\nasync function render(){ const r = await fetch('/state.json?_=' + Date.now()); const s = await r.json(); document.getElementById('title').textContent = s.title || 'Diagram'; const el = document.getElementById('diagram'); el.innerHTML = ''; const id = 'mermaid-' + Math.random().toString(36).slice(2); try { const out = await mermaid.render(id, s.mermaid || 'graph TD\\nA[No diagram]'); el.innerHTML = out.svg; } catch (err) { el.textContent = String(err); } }\nrender(); setInterval(render, 1500);\n</script>\n</body>\n</html>`);
  });
  await new Promise((resolve, reject) => {
    server.listen(0, '127.0.0.1', () => resolve());
    server.once('error', reject);
  });
  state.popoutServer = server;
  state.popoutPort = server.address().port;
  context.subscriptions.push({ dispose: () => server.close() });
  return state.popoutPort;
}

async function openDiagramPopout(context, diagramId) {
  const model = loadPlanModel();
  const diagram = getCurrentDiagram(model, diagramId);
  const state = extensionState(context);
  state.popoutState = { title: diagram.title, mermaid: diagram.mermaid };
  const port = await ensurePopoutServer(context);
  await vscode.env.openExternal(vscode.Uri.parse(`http://127.0.0.1:${port}/`));
}

async function getViewModel(context) {
  const model = loadPlanModel();
  unblockEligibleTasks(model);
  savePlanModel(model);
  const state = extensionState(context);
  return {
    workspaceRoot: getWorkspaceRoot(),
    plan: model,
    diagrams: model.diagrams,
    runningTasks: [...state.processes.keys()],
    hasAgentTemplate: Boolean(getConfig().get('agentCommandTemplate', '').trim())
  };
}

function panelHtml(webview) {
  const nonce = String(Date.now());
  return `<!doctype html>\n<html>\n<head>\n<meta charset="utf-8" />\n<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src ${webview.cspSource} https: data:; style-src ${webview.cspSource} 'unsafe-inline'; script-src 'nonce-${nonce}' https:; connect-src https: http://127.0.0.1:*;">\n<meta name="viewport" content="width=device-width, initial-scale=1.0" />\n<title>Flagship Foundry</title>\n<style>\nbody{font-family:var(--vscode-font-family);padding:10px;color:var(--vscode-foreground)}\n.toolbar{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}\nbutton,select{padding:6px 10px;border-radius:8px;border:1px solid var(--vscode-panel-border);background:var(--vscode-button-background);color:var(--vscode-button-foreground)}\nbutton.secondary{background:var(--vscode-editorWidget-background);color:var(--vscode-foreground)}\n.grid{display:grid;grid-template-columns:320px 1fr;gap:12px}\n.card{border:1px solid var(--vscode-panel-border);border-radius:12px;padding:12px;background:var(--vscode-editorWidget-background)}\n.task{border:1px solid var(--vscode-panel-border);border-radius:10px;padding:10px;margin-bottom:8px}\n.task h4{margin:0 0 6px 0;font-size:14px}\n.task p{margin:0 0 8px 0;font-size:12px;line-height:1.4}\n.task .meta{font-size:11px;opacity:.8;margin-bottom:8px}\n.task .actions{display:flex;gap:6px;flex-wrap:wrap}\n#diagram{min-height:60vh;overflow:auto;border:1px solid var(--vscode-panel-border);border-radius:12px;padding:12px;background:#111}\npre{white-space:pre-wrap;word-break:break-word;font-size:12px}\n.badge{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;border:1px solid var(--vscode-panel-border);margin-right:6px}\n.badge.running{background:#164e63}.badge.ready{background:#1f2937}.badge.completed{background:#14532d}.badge.blocked{background:#7c2d12}.badge.paused{background:#78350f}.badge.failed{background:#7f1d1d}.badge.stopped{background:#374151}\n.small{font-size:12px;opacity:.8}\n</style>\n<script nonce="${nonce}" src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>\n</head>\n<body>\n<div class="toolbar">\n  <button id="refreshBtn">Refresh</button>\n  <button id="approveBtn">Approve plan</button>\n  <label class="small"><input id="autoApproveToggle" type="checkbox" /> Auto approve</label>\n  <button id="scaffoldAgentsBtn" class="secondary">Scaffold Claude agents</button>\n  <button id="ensureMcpBtn" class="secondary">Ensure MCP config</button>\n  <button id="popoutBtn" class="secondary">Pop out diagram</button>\n  <select id="diagramSelect"></select>\n</div>\n<div class="grid">\n  <div class="card">\n    <h3 style="margin-top:0">Tasks</h3>\n    <div id="taskList"></div>\n  </div>\n  <div class="card">\n    <div class="small" id="planMeta"></div>\n    <div id="diagram"></div>\n  </div>\n</div>\n<script nonce="${nonce}">\nconst vscode = acquireVsCodeApi();\nmermaid.initialize({ startOnLoad:false, securityLevel:'loose', theme:'dark', flowchart:{ useMaxWidth:true } });\nlet viewModel = null;\nlet currentDiagramId = null;\nfunction post(type, payload={}){ vscode.postMessage({ type, payload }); }\nasync function renderDiagram(){ if(!viewModel){ return; } const diagrams = viewModel.diagrams || []; const active = diagrams.find(d => d.id === currentDiagramId) || diagrams[0]; const host = document.getElementById('diagram'); if(!active){ host.innerHTML = '<pre>No diagrams found. Add .mmd files under .foundry/diagrams.</pre>'; return; } try { const out = await mermaid.render('m' + Math.random().toString(36).slice(2), active.mermaid || 'graph TD\\nA[No diagram]'); host.innerHTML = out.svg; } catch(err){ host.innerHTML = '<pre>' + String(err) + '</pre>'; } }\nfunction taskBadge(task){ return '<span class="badge ' + (task.status||'ready') + '">' + (task.status||'ready') + '</span>'; }\nfunction renderTasks(){ const list = document.getElementById('taskList'); list.innerHTML = ''; (viewModel.plan.tasks || []).forEach(task => { const div = document.createElement('div'); div.className='task'; div.innerHTML = '<h4>' + task.title + '</h4>' + '<div class="meta">' + taskBadge(task) + '<span class="small">Agent: ' + (task.agent||'n/a') + '</span></div>' + '<p>' + (task.description||'') + '</p>' + '<div class="actions">' + '<button data-action="start">Start</button>' + '<button data-action="watch">Watch</button>' + '<button data-action="pause">Pause</button>' + '<button data-action="resume">Resume</button>' + '<button data-action="stop">Stop</button>' + '</div>'; div.querySelectorAll('button').forEach(btn => { btn.addEventListener('click', () => post('taskAction', { taskId: task.id, action: btn.dataset.action })); }); list.appendChild(div); }); }\nfunction renderDiagrams(){ const sel = document.getElementById('diagramSelect'); sel.innerHTML=''; (viewModel.diagrams || []).forEach(diagram => { const opt = document.createElement('option'); opt.value = diagram.id; opt.textContent = diagram.title; sel.appendChild(opt); }); if((viewModel.diagrams || []).length > 0){ if(!currentDiagramId || !(viewModel.diagrams || []).some(d => d.id === currentDiagramId)){ currentDiagramId = viewModel.diagrams[0].id; } sel.value = currentDiagramId; } }\nfunction renderMeta(){ const approval = viewModel.plan.approval || {}; document.getElementById('planMeta').textContent = 'Plan: ' + (viewModel.plan.title || 'Untitled') + ' | Approval: ' + (approval.status || 'awaiting_approval') + ' | Mode: ' + (approval.mode || 'manual') + (viewModel.hasAgentTemplate ? ' | Runtime: configured' : ' | Runtime: prompt-only'); document.getElementById('autoApproveToggle').checked = Boolean(approval.autoApprove || approval.mode === 'auto'); }\nfunction render(){ renderMeta(); renderTasks(); renderDiagrams(); renderDiagram(); }\ndocument.getElementById('refreshBtn').addEventListener('click', () => post('refresh'));\ndocument.getElementById('approveBtn').addEventListener('click', () => post('approvePlan'));\ndocument.getElementById('autoApproveToggle').addEventListener('change', (e) => post('toggleAutoApprove', { enabled: e.target.checked }));\ndocument.getElementById('scaffoldAgentsBtn').addEventListener('click', () => post('scaffoldAgents'));\ndocument.getElementById('ensureMcpBtn').addEventListener('click', () => post('ensureMcp'));\ndocument.getElementById('popoutBtn').addEventListener('click', () => post('popoutDiagram', { diagramId: currentDiagramId }));\ndocument.getElementById('diagramSelect').addEventListener('change', (e) => { currentDiagramId = e.target.value; renderDiagram(); post('diagramSelected', { diagramId: currentDiagramId }); });\nwindow.addEventListener('message', (event) => { const msg = event.data; if(msg.type === 'viewModel'){ viewModel = msg.payload; render(); } });\npost('refresh');\n</script>\n</body>\n</html>`;
}

async function refreshPanel(context) {
  const state = extensionState(context);
  if (!state.panel) {
    return;
  }
  state.panel.webview.postMessage({ type: 'viewModel', payload: await getViewModel(context) });
}

function openPanel(context) {
  const state = extensionState(context);
  if (state.panel) {
    state.panel.reveal(vscode.ViewColumn.One);
    refreshPanel(context).catch(() => undefined);
    return state.panel;
  }
  const panel = vscode.window.createWebviewPanel('flagshipFoundryControl', 'Flagship Foundry', vscode.ViewColumn.One, {
    enableScripts: true,
    retainContextWhenHidden: true
  });
  state.panel = panel;
  panel.webview.html = panelHtml(panel.webview);
  panel.onDidDispose(() => {
    state.panel = null;
  }, null, context.subscriptions);
  panel.webview.onDidReceiveMessage(async (message) => {
    try {
      const type = message && message.type;
      const payload = (message && message.payload) || {};
      if (type === 'refresh') {
        await refreshPanel(context);
        return;
      }
      if (type === 'approvePlan') {
        await approvePlan(context, false);
        vscode.window.showInformationMessage('Plan approved.');
        return;
      }
      if (type === 'toggleAutoApprove') {
        await toggleAutoApprove(context, Boolean(payload.enabled));
        return;
      }
      if (type === 'scaffoldAgents') {
        const files = generateClaudeAgentFiles();
        vscode.window.showInformationMessage(`Generated ${files.length} Claude agent files.`);
        return;
      }
      if (type === 'ensureMcp') {
        ensureCursorMcpConfig();
        vscode.window.showInformationMessage('Updated .cursor/mcp.json with Flagship Foundry MCP entry.');
        return;
      }
      if (type === 'popoutDiagram') {
        await openDiagramPopout(context, payload.diagramId);
        return;
      }
      if (type === 'diagramSelected') {
        const model = loadPlanModel();
        const diagram = getCurrentDiagram(model, payload.diagramId);
        extensionState(context).popoutState = { title: diagram.title, mermaid: diagram.mermaid };
        return;
      }
      if (type === 'taskAction') {
        if (payload.action === 'start') await startTask(context, payload.taskId);
        if (payload.action === 'watch') await watchTask(context, payload.taskId);
        if (payload.action === 'pause') await pauseTask(context, payload.taskId);
        if (payload.action === 'resume') await resumeTask(context, payload.taskId);
        if (payload.action === 'stop') await stopTask(context, payload.taskId);
        return;
      }
    } catch (error) {
      vscode.window.showErrorMessage(error.message || String(error));
    }
  }, null, context.subscriptions);
  refreshPanel(context).catch((error) => {
    vscode.window.showErrorMessage(error.message || String(error));
  });
  return panel;
}

function registerConfiguration() {
  return {
    title: 'Flagship Foundry',
    properties: {
      'flagshipFoundry.taskFile': {
        type: 'string',
        default: '.foundry/tasks/current-plan.json',
        description: 'Relative path to the active plan/task list JSON file.'
      },
      'flagshipFoundry.diagramDirectory': {
        type: 'string',
        default: '.foundry/diagrams',
        description: 'Relative directory containing Mermaid diagrams for the current workspace.'
      },
      'flagshipFoundry.runtimeDirectory': {
        type: 'string',
        default: '.foundry/runtime',
        description: 'Relative directory used for prompt files and task logs.'
      },
      'flagshipFoundry.agentCommandTemplate': {
        type: 'string',
        default: '',
        description: 'Optional shell command template for starting a task runtime. Use placeholders {workspaceRoot}, {agent}, {taskId}, {title}, and {promptFile}.'
      }
    }
  };
}

function activate(context) {
  createSampleArtifactsIfMissing();
  context.subscriptions.push(
    vscode.commands.registerCommand('flagshipFoundry.openControlCenter', () => openPanel(context)),
    vscode.commands.registerCommand('flagshipFoundry.popoutCurrentDiagram', async () => {
      const model = loadPlanModel();
      const diagram = selectedDiagram(model);
      await openDiagramPopout(context, diagram.id);
    }),
    vscode.commands.registerCommand('flagshipFoundry.scaffoldClaudeSubagents', () => {
      const files = generateClaudeAgentFiles();
      vscode.window.showInformationMessage(`Generated ${files.length} Claude agent files.`);
      return files;
    }),
    vscode.commands.registerCommand('flagshipFoundry.ensureCursorMcp', () => {
      ensureCursorMcpConfig();
      vscode.window.showInformationMessage('Updated .cursor/mcp.json with Flagship Foundry MCP entry.');
    })
  );
}

function deactivate() {
  // Processes are intentionally not force-killed on deactivate.
}

module.exports = {
  activate,
  deactivate,
  registerConfiguration
};
